# Chrome Extension Template

## What it currently does
    > A small popup extension that changes a webpages background color
    using a dropdown menu selection.  Can also save choices for next time
    you visit the same page.

## Local Setup
    > Open Chrome browser
    > go to chrome://extensions
        > check "Developer mode" in upper-right hand corner
    > "Load unpacked extension..."
    > Select directory that files live in
        > Open entire directory
    
    If error:
        > message will display at top of page (not console)
    If swag:
        > click icon on top-right to play with the plugin!